export function SearchBar() {
    return (
        <>

            <div class="topnav">
                <br />
                <input type="text" placeholder="Search by player name or game name.."></input>
                <input type="submit"></input>
            </div>
        </>
    )
}