const Header = () => {
    return (
        <header>
            <h1>RPG Tracks</h1>
            <p>Keeping all those things together.</p>
        </header>
    );
};

export default Header;